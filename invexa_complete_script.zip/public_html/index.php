<!DOCTYPE html>
<html>
<head>
  <title>Invexa - Home</title>
</head>
<body>
  <h1>Welcome to Invexa</h1>
  <p><a href="register.php">Register</a> | <a href="login.php">Login</a></p>
</body>
</html>
