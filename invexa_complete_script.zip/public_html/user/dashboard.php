<?php
session_start();
if (!isset($_SESSION['email'])) { header("Location: ../login.php"); exit(); }
echo "<h1>Invexa Dashboard</h1>";
echo "<p>Wallet Balance: Rs. 0</p>";
echo "<p><a href='../ads/index.php'>Watch Ads</a> | <a href='../referral/index.php'>Referral</a></p>";
echo "<a href='../logout.php'>Logout</a>";
?>
