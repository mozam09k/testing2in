<?php
session_start();
if (!isset($_SESSION['email'])) { header("Location: ../login.php"); exit(); }
echo "<h1>Referral System</h1>";
echo "<p>Referral Link: yourdomain.com/register.php?ref=123</p>";
?>
