<?php
session_start();
if (!isset($_SESSION['email'])) { header("Location: ../login.php"); exit(); }
echo "<h1>Watch Ads</h1>";
echo "<p>Ad 1 - Rs. 2 <a href='#'>Watch Now</a></p>";
echo "<p>Ad 2 - Rs. 2 <a href='#'>Watch Now</a></p>";
?>
